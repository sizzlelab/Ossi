SIS_VERSION = "0.1"
APP_TITLE = u"Sissi"

import appuifw
import e32
appuifw.app.orientation = 'portrait'
import time

class Logger:
    def __init__ (self, filename = 'C:\\data\\sissi.log'):
        self.fname = filename
    def write(self, obj):
        timestamp = time.strftime("%Y%m%d-%H%M%S\r\n")
        log = open(self.fname, 'at')
        log.write(timestamp)
        log.write(obj)
        log.write("\r\n")
        log.close()
    def flush(self):
        pass


#### STARTUP "splash screen"
def startup_screen(dummy=(0, 0, 0, 0)):
    pass
    
def draw_startup_screen(canvas, text):
    canvas.clear()
    canvas.add("loading "+text)
    e32.ao_sleep(0.01) # Wait until the canvas has been drawn

canvas = appuifw.Text()
canvas.font = u"LatinPlain15"
appuifw.app.body = canvas
draw_startup_screen(canvas, u"sys")
import sys
draw_startup_screen(canvas, u"os, socket")
import os
import socket
draw_startup_screen(canvas, u"time, copy")
import time
import copy
draw_startup_screen(canvas, u"scanner")
from Scanner import Scanner
draw_startup_screen(canvas, u"netmapper")
from NetMapper import NetMapper
import pys60_simplejson
simplejson = pys60_simplejson.simplejson()
draw_startup_screen(canvas, u"graphics")
import graphics

####################################
# FIXME: move these to an own module
import math
rad=math.pi/180

def project_point(x0, y0, dist, angle):
    """Project a new point from point x0,y0 to given direction and angle."""
    # TODO: check that the docstring is correct
    # TODO: check that alghorithm below is correct
    y1 = y0 + math.cos(angle * rad) * dist
    x1 = x0 + math.cos((90 - angle) * rad) * dist
    return x1, y1

def slope(x0, y0, x1, y1):
    """Calculate the slope of the line joining two points."""
    if x0 == x1: return 0
    return 1.0*(y0-y1)/(x0-x1)

def intercept(x, y, a):
    """Return the y-value (c) where the line intercepts y-axis."""
    # TODO: check that the docstring is correct
    return y-a*x

def distance(a,b,c,m,n):
    return abs(a*m+b*n+c)/math.sqrt(a**2+b**2)

def distance_from_vector(x0, y0, dist, angle, x, y):
    x1, y1 = project_point(x0, y0, dist, angle)
    a = slope(x0, y0, x1, y1)
    c = intercept(x0, y0, a)
    dist = distance(a, -1, c, x, y)
    return dist

def distance_from_line(x0, y0, x1, y1, x, y):
    a = slope(x0, y0, x1, y1)
    c = intercept(x0, y0, a)
    dist = distance(a, -1, c, x, y)
    return dist
####################################



class SissiApp:
    __id__ = u'Sissi'
    __version__ = u'0.1'

    def update_screen(self):
      text = ""
      if self.scanner.text != None:
        text += self.scanner.text
      if self.netmapper.text != None:
        text += self.netmapper.text
      self.draw_screen(text)

    def draw_screen(self, text):
      self.canvas.clear()
      self.canvas.add(u""+text)
      e32.ao_sleep(0.01) # Wait until the canvas has been drawn

    def debug(self, obj):
      self.canvas.clear()
      self.canvas.add(u""+simplejson.dumps(obj)+"\n")
#      for item in obj:
#        self.canvas.add(u""+str(item['rxlevel'])+"\n")
#        for k,v in item.items():
#          self.canvas.add(u""+str(k)+"\n")


#        self.canvas.add(u""+item+"\n")

#      e32.ao_sleep(0.01) # Wait until the canvas has been drawn

    def __init__(self):
        appuifw.app.title = u"Sissi"
        self.canvas = canvas
        self.Main = self # This is the base of all views, tabs etc.
        self.lock = e32.Ao_lock()
        self.datadir = os.path.join(u"C:\\Data", u"Sissi")
        if not os.path.exists(self.datadir):
            os.makedirs(self.datadir)
        # Create a directory for temporary data
        self.cachedir = u"D:\\Sissi"
        if not os.path.exists(self.cachedir):
            os.makedirs(self.cachedir)
        # Configuration/settings
        self.draw_screen('reading config')
        self.config_file = os.path.join(self.datadir, "settings.ini")
        self.config = {} # TODO: read these from a configuration file
        self.apid = None # Default access point
        self.read_config()
        if self.config.has_key("apid"):
            self._select_access_point(self.config["apid"])
        self.data = {}
        self.scanner = Scanner(self)
        self.netmapper = NetMapper(self)
        self.scanner.set_extra_handler(self.query_location)
        appuifw.app.exit_key_handler = self.exit_key_handler
        self._update_menu()
        self.draw_screen('ready!')
        self.scanner_handler() # start scanning automatically

    def open_ossi(self):
      	path = u"e:\\python\\ossi.html"
      	c=appuifw.Content_handler()
      	c.open(path)
      	app_lock = e32.Ao_lock()
      	app_lock.wait()
      	appuifw.app.exit_key_handler = self.exit_key_handler

    def _select_access_point(self, apid = None):
        """
        Shortcut for socket.select_access_point() 
        TODO: save selected access point to the config
        TODO: allow user to change access point later
        """
        if apid is not None:
            self.apid = apid
        else:
            access_points = socket.access_points()
            sort_key = "iapid"
            decorated = [(dict_[sort_key], dict_) for dict_ in access_points]
            decorated.sort()
            access_points = [dict_ for (key, dict_) in decorated]
            ap_names = [dict_["name"] for dict_ in access_points]
            ap_ids = [dict_["iapid"] for dict_ in access_points]
            selected = appuifw.selection_list(ap_names, search_field=1)
            #print selected, ap_names[selected], ap_ids[selected]
            if selected is not None:
                self.apid = ap_ids[selected]
        if self.apid:
            self.apo = socket.access_point(self.apid)
            socket.set_default_access_point(self.apo)
            self.config["apid"] = self.apid
            self.save_config()
            self._update_menu()
            return self.apid

    def _update_menu(self):
        scanner_string = 'Start'
        if self.__dict__.has_key("scanner"): # check that scanner has been initialized
          if self.scanner.running:
            scanner_string = 'Stop'

        appuifw.app.menu = [
            (u""+scanner_string+" scanner", self.scanner_handler),
#            (u"Query ONM", self.query_location),
            (u"Reset config", self.reset_config),
            (u"About", lambda:appuifw.note("OtaSizzle S60 daemon. Version: " + self.__version__ + "\n\nJT/HIIT", 'info')),
            (u"Close", self.exit_key_handler),
            ]

    def read_config(self):
        data = {}
        try:
            f = open(self.config_file, "rt")
            data = eval(f.read())
            #data = f.read()
            f.close()
        except:
            appuifw.note(u"Generating a settings file...", 'info')
            # raise
        # List here ALL POSSIBLE configuration keys, so they will be initialized
        defaults = {
            "otasizzle_username" : None,
            "otasizzle_password" : None,
            "cos_url" : u"http://cos.sizl.org",
            "apid" : None,
            "onm_url" : u"http://opennetmap.org/api/?operation=get_wlan_01&wlan_ids=",
            "script" : u"/api/",
        }
        # List here all configuration keys, which must be defined before use
        # If a config key has key "function", it's called to define value
        # TODO: make some order for these
        mandatory = {
            "otasizzle_username" : {"querytext" : u"your OtaSizzle username", 
                          "valuetype" : "text", 
                          "default" : u'',
                          "canceltext" : u'username is mandatory!',
                          },
            "otasizzle_password" : {"querytext" : u"your OtaSizzle password", 
                          "valuetype" : "text", 
                          "default" : u'',
                          "canceltext" : u'password is mandatory!',
                          },
            "apid"    : {"querytext" : u"Select default data connection!", 
                          "valuetype" : "function",
                          "default" : u'',
                          "canceltext" : None,
                          "function" : self._select_access_point,
                          },
        }
        # Loop all possible keys (found from defaults)
        for key in defaults.keys():
            if data.has_key(key): # Use the value found from the data
                defaults[key] = data[key]
            elif mandatory.has_key(key) and defaults[key] is None: # Ask mandatory values from the user
                value = None
                if mandatory[key].has_key("function"): # if defined, call the "function"
                    appuifw.note(mandatory[key]["querytext"], 'info')
                    value = mandatory[key]["function"]() # "function" must return a value
                else:
                    while value is None:
                        value = appuifw.query(mandatory[key]["querytext"], 
                                              mandatory[key]["valuetype"], 
                                              mandatory[key]["default"])
                        if value is None and mandatory[key]["canceltext"]: 
                            appuifw.note(mandatory[key]["canceltext"], 'error')
                        elif value is None: # If canceltext is u"", change value None to u""
                            value = u""
                defaults[key] = value
        self.config = defaults
        self.save_config()
        
    def save_config(self):
        f = open(self.config_file, "wt")
        f.write(repr(self.config))
        f.close()

    def reset_config(self):
        if appuifw.query(u'Are you sure you want to delete all settings?', 'query') is True:
            os.remove(self.config_file)
            # TODO: create combined exit handler
#            self.save_log_cache("track")
#            self.save_log_cache("cellid") 
            appuifw.note(u"Done, now you need to restart Sissi!", 'info')
            self.running = False
            self.lock.signal()
            appuifw.app.exit_key_handler = None
            appuifw.app.set_tabs([u"Back to normal"], lambda x: None)

    def scanner_handler(self):
      if self.scanner:
        if self.scanner.running:
          self.scanner.stop()
        else:
          self.scanner.start()
      self._update_menu()
      appuifw.app.exit_key_handler = self.exit_key_handler
      appuifw.app.set_tabs([u"Back to normal"], lambda x: None)

    def query_location(self):
      wlanlist = self.scanner.position["wlan_data"]["wlanlist"]
      wlanlist.sort(lambda x, y: cmp(y['rxlevel'], x['rxlevel']))
      if len(wlanlist) > 1:
        self.netmapper.get_location(wlanlist[0]["bssid"],wlanlist[1]["bssid"])
      appuifw.app.exit_key_handler = self.exit_key_handler
      appuifw.app.set_tabs([u"Back to normal"], lambda x: None)

    def run(self):
        self.lock.wait()
        self.close()

    def exit_key_handler(self):
        if appuifw.query(u"Quit program", 'query') is True:
            self.running = False
            self.scanner.stop()
            self.lock.signal()

    def close(self):
#        positioning.stop_position()
        appuifw.app.exit_key_handler = None
        self.running = False
        appuifw.app.set_tabs([u"Back to normal"], lambda x: None)

# Exception harness for test versions
try:
    oldbody = appuifw.app.body
    myApp = SissiApp()
    myApp.run()
    appuifw.app.body = oldbody
#    positioning.stop_position()
except:
    # Exception harness
#    positioning.stop_position()
    import sys
    import traceback
    import e32
    import appuifw
    appuifw.app.screen = "normal"               # Restore screen to normal size.
    appuifw.app.focus = None                    # Disable focus callback.
    body = appuifw.Text()
    appuifw.app.body = body                     # Create and use a text control.
    exitlock = e32.Ao_lock()
    def exithandler(): exitlock.signal()
    appuifw.app.exit_key_handler = exithandler  # Override softkey handler.
    appuifw.app.menu = [(u"Exit", exithandler)] # Override application menu.
    body.set(unicode("\n".join(traceback.format_exception(*sys.exc_info()))))
    try:
        body.add(u"\n".join(App.log))
    except:
        pass
        #body.set(unicode("\n".join(traceback.format_exception(*sys.exc_info()))))
    exitlock.wait()                             # Wait for exit key press.
    
#positioning.stop_position()
e32.ao_sleep(1)
# For SIS-packaged version uncomment this:
# appuifw.app.set_exit()
